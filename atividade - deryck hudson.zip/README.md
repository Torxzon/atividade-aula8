Executar projeto baixado
Instalar as dependências
### `npm install install`

Rodar o projeto React
### `npm start`

Instalar o axios
### `npm install --save axios`